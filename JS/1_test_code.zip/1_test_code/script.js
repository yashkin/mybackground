const param = {
    "url": "https://api.openweathermap.org/data/2.5/",
    "appid": "d9993e06530e532c7e2d25dfb3e06f4d"
}

function getWeather() {
    const cityId = document.querySelector('#cities').value;
    fetch(`${param.url}weather?id=${cityId}&units=metric&APPID=${param.appid}`)
        .then(weather => {
            return weather.json();
        }).then(showWeather);
}


function showWeather(data) {
    console.log(data);
    let box = document.querySelector('.box__data');

    let city = document.querySelector('.box__data-city');
    let temperature = box.querySelector('.box__data-temperature');
    let feels = box.querySelector('.box__data-feels');
    let icon = box.querySelector('.box__data-icon');
    let descrtiption = box.querySelector('.box__data-descrtiption');
    let humidity = box.querySelector('.box__data-humidity');
    let pressure = box.querySelector('.box__data-pressure');
    let wind = box.querySelector('.box__data-wind');

    city.textContent = 'City: ' + data.name;
    temperature.innerHTML = Math.round(data.main.temp) + '&deg' + 'C';
    feels.innerHTML = 'feels like: ' + Math.round(data.main.feels_like) + '&deg' + 'C';
    icon.innerHTML = `<img src="http://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png" alt="weather icon">`;
    descrtiption.textContent = data.weather[0].description;
    humidity.textContent = 'humidity: ' + data.main.humidity + '%';
    pressure.textContent = 'pressure: ' + data.main.pressure + ' Mst';
    wind.textContent = 'wind speed: ' + data.wind.speed + ' M/s'
}
const cities = {
    2968815: 'Paris',
    2643743: 'London',
    625144: 'Minsk',
    2759794: 'Amsterdam',
    703448: 'Kyiv'
}

function init() {
    // просто в функцию собрал чтобы не валялось в коде
    let select = document.createElement('select');
    select.id = 'cities';
    select.classList.add('select');

    for (let key in cities) {
        let option = document.createElement('option');
        option.value = key;
        option.textContent = cities[key];
        select.appendChild(option);

    }
    let boxInner = document.querySelector('.box__inner');
    boxInner.append(select);
}

init(); // вначале отрисовываем
// потом получаем данные 
getWeather();
document.querySelector('#cities').onchange = getWeather;