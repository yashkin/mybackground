const param = {
    "url" : "api.openweathermap.org/data/2.5/",
    "appid" : "be102922df59499a2cd6fa6e09a5f5e8"
    
}

function getWeather() {
    const cityId = document.querySelector('#city').value;
    fetch (`${param.url} weather ? id = ${cityId} & units = metric & APPID = ${param.appid}`)
    .then(weather => {
        return weather.json();
    })
    .then(showWeather);
}

function showWeather(data) {
    document.querySelector('.weather_city').textContent = data.name;
    document.querySelector('.weather_wind').textContent = 'Wind' + ' ' + Math.round(data.wind.speed) + ' ' + 'm/s';
    document.querySelector('.features_icon').innerHTML = `<img src="https://openweathermap.org/img/wn/${data.weather[0]['icon']}@2x.png">`;
    document.querySelector('.weather_forecast').innerHTML = Math.round(data.main.temp) + "&deg";
    console.log(data); 
}

getWeather();
document.querySelector('#city').onchange = getWeather;