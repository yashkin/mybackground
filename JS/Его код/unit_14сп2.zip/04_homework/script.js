const param = {
	"url" : "https://api.openweathermap.org/data/2.5/weather?lat=53.200001&lon=50.150002&appid=3319f38d51f87390bf99c5a9e53c78bf",
	"appid" : "3319f38d51f87390bf99c5a9e53c78bf"
}

function getWeather() {
	const cityId = document.querySelector('#city').value;
	fetch(`${param.url}weather?id=${cityId}&units=metric&APPID=${param.appid}`)
	.then(weather => {
			return weather.json();
		}).then(showWeather);
}

function showWeather(data) {
	console.log(data);
}

getWeather(); 
document.querySelector('#city').onchange = getWeather;