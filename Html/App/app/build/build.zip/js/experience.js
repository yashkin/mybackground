const experience = [
    {
        "company": "COMPANY NAME 3",
        "city": "Tayler",
        "from": "2016",
        "to": 'Present',
        "position": "your position",
        "description": "Replace with your key responsibilities, accomplishments and skills that may relevant to the position you are applying for Include the keywords from the listing to capture the employer’s attention and to match applicant tracking system requirements Transform your responsibilities into quantifiable achievements by brainstorming for any numbers relevant to your key duties"
    },
    {
        "company": "COMPANY NAME",
        "city": "NEW YORK",
        "from": "2016",
        "to": 'Present',
        "position": "your position",
        "description": "Replace with your key responsibilities, accomplishments and skills that may relevant to the position you are applying for Include the keywords from the listing to capture the employer’s attention and to match applicant tracking system requirements Transform your responsibilities into quantifiable achievements by brainstorming for any numbers relevant to your key duties"
    },
    {
        "company": "COMPANY NAME 2",
        "city": "Odessa",
        "from": "2017",
        "to": '2021',
        "position": "your position",
        "description": "Replace with your key responsibilities, accomplishments and skills that may relevant to the position you are applying for Include the keywords from the listing to capture the employer’s attention and to match applicant tracking system requirements Transform your responsibilities into quantifiable achievements by brainstorming for any numbers relevant to your key duties"
    }
]